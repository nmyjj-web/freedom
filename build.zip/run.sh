dir1="./sdcard/ppSR/misc"
dir2="./build/misc"

mkdir -p "$dir2"
for filepath in "$dir1"/*; do
  [ -e "$filepath" ] || continue
  basefile=$(basename "$filepath")
  file1="$dir1/$basefile"
  file2="$dir2/$basefile"

  if [ "$file1" -nt "$file2" ]; then
    cp -a "$file1" "$dir2/"
  else
    [ -e "$file2" ] && cp -a "$file2" "$dir1/"
  fi
done

cd build && python ppsr.pyc
