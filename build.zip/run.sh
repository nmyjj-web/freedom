dir1="./storage/shared/ppSR/misc/"
dir2="./build/misc/"
for filename in "$dir1"/*; do
    basefile=$(basename "$filename")

    file1="$dir1/$basefile"
    file2="$dir2/$basefile"

    if [ "$file1" -nt "$file2" ]; then
        # file1 is newer
        cp "$file1" "$dir2/" -rf
    else
        # file2 is newer or same
        cp "$file2" "$dir1/" -rf
    fi
done
cd build
python ppsr.pyc